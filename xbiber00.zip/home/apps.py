# -*- coding: utf-8 -*-

from django.apps import AppConfig

class HomeAppConfig(AppConfig):
    name = 'home'
    verbose_name = 'MULTube'
    
